const { User, Event, UserInterest, UserFavoriteEvent, Registration } = require("../models");
const { Op } = require("sequelize");

//Controller for event recommendations and featured events
//Logic and implementation by Akshaya singam and Yash Dodiya

//Get today's date with time set to 00:00:00
function getToday() {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  return today;
}

//Get date two months from today
function getTwoMonthsFromToday() {
  const d = getToday();
  d.setMonth(d.getMonth() + 2);
  return d;
}

//-------------Code by Akshaya Singam

//Featured events based on momentum and recency
exports.getFeaturedEvents = async (req, res) => {
  try {
    const limit = Math.min(parseInt(req.query.limit) || 10, 20);
    const debug = req.query.debug === "true";

    //Fetch approved events
    const events = await fetchApprovedEvents({ withinTwoMonths: true });

    const scored = events.map((event) => {
      //Calculate scores
      const breakdown = calculateFeaturedScore(event);
      return { event, score: breakdown.total, breakdown };
    });

    //Rank events by score and limit results
    const topEvents = rankAndLimit(scored, limit);

    res.json({
      events: topEvents.map((e) =>
        formatEventResponse(e.event, e.score, debug ? e.breakdown : undefined)
      ),
    });
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch featured events" });
  }
};

//Fetch approved events
async function fetchApprovedEvents({ withinTwoMonths = false }) {
  const today = getToday();
  const dateFilter = { [Op.gte]: today };

  if (withinTwoMonths) {
    dateFilter[Op.lte] = getTwoMonthsFromToday();
  }

  return Event.findAll({
    where: {
      status: "approved",
      date: dateFilter,
    },
    include: [
      { association: "category", attributes: ["id", "name"] },
      { association: "subcategories", attributes: ["id", "name"] },
      { association: "organizer", attributes: ["id", "name", "email"] },
      { association: "venue" },
      { association: "participants", attributes: ["id"] },
      { association: "feedback", attributes: ["id", "rating"] },
    ],
  });
}

//Calculate momentum and recency scores for featured events
function calculateFeaturedScore(event) {
  const today = getToday();
  const participants = event.participants?.length || 0;

  //Momentum score(0-10)
  let momentumScore = 0;
  if (event.registration_start_date && participants > 0) {
    const daysSinceOpen = Math.max(
      1,
      Math.ceil((today - new Date(event.registration_start_date)) / 86400000)
    );
    const participantsPerDay = participants / daysSinceOpen; // participants per day

    // Normalize: assuming 5+ participants/day is excellent
    momentumScore = Math.min(10, (participantsPerDay / 5) * 10);
  } else if (participants > 0) {
    momentumScore = Math.min(10, (participants / 20) * 10);
  }

  const daysUntilEvent = Math.ceil((new Date(event.date) - today) / 86400000);
  let recencyScore = 0;
  if (daysUntilEvent <= 7)
    recencyScore = 5; // This week
  else if (daysUntilEvent <= 14)
    recencyScore = 4; // Next week
  else if (daysUntilEvent <= 30)
    recencyScore = 3; // This month
  else if (daysUntilEvent <= 45)
    recencyScore = 2; // 1.5 months
  else recencyScore = 1; // Within 2 months

  return {
    participants,
    momentumScore,
    recencyScore,
    daysUntilEvent,
    total: momentumScore + recencyScore,
  };
}

//Rank events by score and limit results
function rankAndLimit(scoredEvents, limit) {
  return scoredEvents.sort((a, b) => b.score - a.score).slice(0, limit);
}

//Format event response with score and breakdown for debugging
function formatEventResponse(event, score, breakdown) {
  return {
    id: event.id,
    title: event.title,
    description: event.description,
    banner_image: event.banner_image,
    price: event.price,
    date: event.date,
    start_time: event.start_time,
    end_time: event.end_time,
    max_participants: event.max_participants,
    organizer: event.organizer || null,
    venue: event.venue || null,
    category: event.category || null,
    subcategories: event.subcategories || [],
    score,
    breakdown,
  };
}

//Calculate interest score based on matching categories and subcategories
function calculateInterestScore(event, interestSubcategoryIds, interestCategoryIds) {
  const eventSubcatIds = (event.subcategories || []).map((s) => s.id);

  // Count matching subcategories
  const matchingSubcategoriesCount = eventSubcatIds.filter((id) =>
    interestSubcategoryIds.has(id)
  ).length;

  // Check if category matches (0 or 1)
  const matchingCategoriesCount = interestCategoryIds.has(event.categoryId) ? 1 : 0;

  const subcategoryScore = matchingSubcategoriesCount * 10;
  const categoryScore = matchingCategoriesCount * 5;

  return {
    matchingSubcategoriesCount,
    matchingCategoriesCount,
    subcategoryScore,
    categoryScore,
    total: subcategoryScore + categoryScore,
  };
}

//-------------Code by Yash Dodiya

//Recommendations based on user interests and event popularity
exports.getEventRecommendations = async (req, res) => {
  try {
    const userId = req.user?.id;
    if (!userId) return res.status(401).json({ error: "Unauthorized" });

    //get user interests
    const { categoryIds, subcategoryIds, count } = await getUserInterestSets(userId);

    if (!count) {
      return res.json({ events: [], message: "No interests found." });
    }

    //get user registered events
    const registeredEventIds = await getRegisteredEventIds(userId);
    const events = await fetchApprovedEvents({ withinTwoMonths: false });

    const eligibleEvents = events.filter((e) => !registeredEventIds.has(e.id));

    //max registrations for popularity scoring
    const maxRegistrations = Math.max(0, ...eligibleEvents.map((e) => e.participants?.length || 0));

    const scored = eligibleEvents.map((event) => {
      const interest = calculateInterestScore(event, subcategoryIds, categoryIds);
      const popularity = calculatePopularityScore(event, maxRegistrations);

      return {
        event,
        score: interest.total + popularity.popularity,
        breakdown: { ...interest, ...popularity },
      };
    });

    const limit = Math.min(parseInt(req.query.limit) || 8, 20);
    const debug = req.query.debug === "true";
    const topEvents = rankAndLimit(scored, limit);

    //Apply subcategory filtering: max 3 per subcategory in top results
    const limitPerSubcategory = 3;
    const diversifiedEvents = applyDiversityConstraints(topEvents, limit, limitPerSubcategory);

    res.json({
      events: diversifiedEvents.map((e) =>
        formatEventResponse(e.event, e.score, debug ? e.breakdown : undefined)
      ),
      interestsCount: count,
    });
  } catch (err) {
    res.status(500).json({ error: "Failed to generate recommendations" });
  }
};

//Get user interests and return sets of category and subcategory IDs
async function getUserInterestSets(userId) {
  const interests = await UserInterest.findAll({
    where: { userId },
    attributes: ["categoryId", "subcategoryId"],
  });

  return {
    categoryIds: new Set(interests.map((i) => i.categoryId).filter(Boolean)),
    subcategoryIds: new Set(interests.map((i) => i.subcategoryId).filter(Boolean)),
    count: interests.length,
  };
}

//Get event IDs of events the user is registered for to exclude from recommendations
async function getRegisteredEventIds(userId) {
  const registrations = await Registration.findAll({
    where: { userId },
    attributes: ["eventId"],
  });
  return new Set(registrations.map((r) => r.eventId));
}

//Calculate popularity score based on registrations and average rating
function calculatePopularityScore(event, maxRegistrations) {
  const registrations = event.participants?.length || 0;

  const registrationsScore = maxRegistrations > 0 ? 3 * (registrations / maxRegistrations) : 0;

  const ratings = (event.feedback || []).map((f) => f.rating).filter((r) => typeof r === "number");

  const avgRating = ratings.length > 0 ? ratings.reduce((a, b) => a + b, 0) / ratings.length : 0;

  let ratingScore = 0;
  if (avgRating >= 4.5) ratingScore = 2;
  else if (avgRating >= 4.0) ratingScore = 1;

  return {
    registrationsScore,
    ratingScore,
    popularity: Math.min(5, registrationsScore + ratingScore),
  };
}

/**
 * Apply diversity constraint: max N events per subcategory
 * @param {Array} scoredEvents - Array of {event, score, breakdown}
 * @param {number} limit - Max total events to return
 * @param {number} limitPerSubcategory - Max events per subcategory
 * @returns {Array} Filtered array respecting caps
 */
function applyDiversityConstraints(scoredEvents, limit, limitPerSubcategory) {
  const subcatCounts = new Map();
  const picked = [];

  for (const item of scoredEvents) {
    if (picked.length >= limit) break;

    const subcats = item.event.subcategories || [];
    // Use primary subcategory (first one) for tracking
    const primarySubcatId = subcats.length > 0 ? subcats[0].id : null;

    const current = subcatCounts.get(primarySubcatId) || 0;
    if (current >= limitPerSubcategory) continue;

    subcatCounts.set(primarySubcatId, current + 1);
    picked.push(item);
  }

  return picked;
}