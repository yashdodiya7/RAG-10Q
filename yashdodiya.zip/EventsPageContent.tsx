"use client";

import { useState, useMemo, useEffect, useCallback, useRef } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Button, Checkbox, EventCard, Spinner } from "@/components/ui";
import useGetEvents from "@/hooks/useGetAllEvents";
import { useAuth } from "@/lib/context/AuthContext";
import {
  Plus,
  Filter,
  X,
  Search,
  AlertCircle,
  ArrowUp,
  Calendar,
  User,
  Tag,
  ChevronLeft,
  ChevronRight,
  SlidersHorizontal,
  Sparkles,
  Zap,
} from "lucide-react";
import NotFound from "../not-found";
import { useToggleFavourite, useIsMobile, useAISearch } from "@/hooks";
import { set } from "zod";
import { Switch } from "@/components/ui/switch";

// --- Helper Functions ---

// 1. Robust Date Parser (Fixes Timezones & Invalid inputs)
const parseLocalDate = (dateStr: string): Date => {
  if (!dateStr) return new Date();

  const parts = dateStr.split("-");
  if (parts.length === 3) {
    const year = parseInt(parts[0], 10);
    const month = parseInt(parts[1], 10) - 1; // 0-indexed
    const day = parseInt(parts[2], 10);

    if (
      Number.isNaN(year) ||
      Number.isNaN(month) ||
      Number.isNaN(day) ||
      month < 0 ||
      month > 11 ||
      day < 1 ||
      day > 31
    ) {
      return new Date(dateStr);
    }

    const candidate = new Date(year, month, day);
    if (
      candidate.getFullYear() !== year ||
      candidate.getMonth() !== month ||
      candidate.getDate() !== day
    ) {
      return new Date(dateStr);
    }

    return candidate;
  }
  return new Date(dateStr);
};

// 2. Main Filter Logic
const isDateInRange = (eventDateStr: string, filterType: string, specificDate: string) => {
  const eventDate = parseLocalDate(eventDateStr);
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  switch (filterType) {
    case "today":
      return eventDate.getTime() === today.getTime();

    case "tomorrow":
      const tomorrow = new Date(today);
      tomorrow.setDate(today.getDate() + 1);
      return eventDate.getTime() === tomorrow.getTime();

    case "week": {
      const currentDay = today.getDay() || 7;
      const monday = new Date(today);
      if (currentDay !== 1) {
        monday.setDate(today.getDate() - (currentDay - 1));
      }
      const endOfWeek = new Date(monday);
      endOfWeek.setDate(monday.getDate() + 6);
      return eventDate.getTime() >= monday.getTime() && eventDate.getTime() <= endOfWeek.getTime();
    }

    case "weekend": {
      const currentDay = today.getDay(); // 0=Sun, 1=Mon...

      // FIX (Copilot): Handle Sunday correctly.
      if (currentDay === 0) {
        // If today is Sunday, "This Weekend" implies Today only.
        // Do NOT show Saturday (yesterday) as it is in the past.
        return eventDate.getTime() === today.getTime();
      } else {
        // Mon-Sat: Find next Saturday
        const diffToSat = 6 - currentDay;
        const saturday = new Date(today);
        saturday.setDate(today.getDate() + diffToSat);
        const sunday = new Date(saturday);
        sunday.setDate(saturday.getDate() + 1);
        return (
          eventDate.getTime() === saturday.getTime() || eventDate.getTime() === sunday.getTime()
        );
      }
    }

    case "month":
      return (
        eventDate.getMonth() === new Date().getMonth() &&
        eventDate.getFullYear() === new Date().getFullYear()
      );

    case "specific":
      if (!specificDate) return true;
      const filterDate = parseLocalDate(specificDate);
      return eventDate.getTime() === filterDate.getTime();

    default:
      return true;
  }
};

export function EventsPageContent() {
  const router = useRouter();
  const { data: initialEvents = [], isLoading: isInitialLoading, error } = useGetEvents();
  const { user } = useAuth();
  const { favouriteEventIds, toggleFavourite } = useToggleFavourite();
  const searchParams = useSearchParams();
  // Yash Dodiya
  const { search: aiSearch, isLoading: isAISearching, error: aiSearchError } = useAISearch();

  // Get query from URL
  const urlQuery = searchParams.get("query") || "";

  // Yash Dodiya
  // --- NEW: AI Mode Toggle ---
  const [isAIMode, setIsAIMode] = useState(false);
  const [aiResponse, setAIResponse] = useState<string | null>(null);

  // --- State Management ---
  const [searchQuery, setSearchQuery] = useState(urlQuery);
  const [searchResults, setSearchResults] = useState<any[] | null>(null);
  const [isSearching, setIsSearching] = useState(false);
  const [searchError, setSearchError] = useState("");
  const [suggestions, setSuggestions] = useState<any[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);

  // FIX (Copilot): Add state for keyboard navigation
  const [activeIndex, setActiveIndex] = useState(-1);

  const searchContainerRef = useRef<HTMLDivElement>(null);
  const skipSuggestionFetch = useRef(false);
  const hasSearchedUrlQuery = useRef(false);

  // Pagination State
  const [currentPage, setCurrentPage] = useState(1);
  const ITEMS_PER_PAGE = 9;

  const isMobile = useIsMobile();

  // Filters State
  const [filters, setFilters] = useState({
    category: "",
    price: "",
    language: "",
    venue: "",
    organizer: "",
    dateFilter: "",
    specificDate: "",
    registrationsOpen: false,
  });

  const [showScrollTop, setShowScrollTop] = useState(false);

  useEffect(() => {
    const handleScroll = () => setShowScrollTop(window.scrollY > 400);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToTop = () => window.scrollTo({ top: 0, behavior: "smooth" });

  // --- Suggestion Fetcher ---
  useEffect(() => {
    if (skipSuggestionFetch.current) {
      skipSuggestionFetch.current = false;
      return;
    }
    if (searchQuery.length < 2) {
      setSuggestions([]);
      setShowSuggestions(false);
      setActiveIndex(-1); // Reset index on new search
      return;
    }

    const delayDebounceFn = setTimeout(async () => {
      try {
        const baseUrl = process.env.NEXT_PUBLIC_API_URL || "http://localhost:4000";
        const res = await fetch(
          `${baseUrl}/api/search/suggestions?query=${encodeURIComponent(searchQuery)}`
        );

        if (!res.ok) throw new Error("Failed to fetch suggestions");

        const data = await res.json();
        if (data.suggestions) {
          setSuggestions(data.suggestions);
          setShowSuggestions(true);
          setActiveIndex(-1);
        }
      } catch (error) {
        console.error("Suggestion fetch error", error);
      }
    }, 300);

    return () => clearTimeout(delayDebounceFn);
  }, [searchQuery]);

  // Click Outside Handler
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (
        searchContainerRef.current &&
        !searchContainerRef.current.contains(event.target as Node)
      ) {
        setShowSuggestions(false);
        setActiveIndex(-1);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // --- Handlers ---
  const handleSuggestionClick = (suggestion: any) => {
    skipSuggestionFetch.current = true;
    setShowSuggestions(false);
    setActiveIndex(-1);

    if (suggestion.type === "Category") {
      setSearchQuery(suggestion.text);
      const params = new URLSearchParams(searchParams.toString());
      params.set("query", suggestion.text);
      router.push(`/events?${params.toString()}`);
    } else if (suggestion.type === "Event") {
      router.push(`/events/${suggestion.id}`);
    } else if (suggestion.type === "Organizer") {
      // FIX (Copilot): Correct route for public organizer profile
      router.push(`/organizer/${suggestion.id}`);
    }
  };

  // FIX (Copilot): Keyboard Navigation Handler
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (!showSuggestions || suggestions.length === 0) return;

    if (e.key === "ArrowDown") {
      e.preventDefault();
      setActiveIndex((prev) => (prev < suggestions.length - 1 ? prev + 1 : prev));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setActiveIndex((prev) => (prev > 0 ? prev - 1 : -1));
    } else if (e.key === "Enter" && activeIndex >= 0) {
      e.preventDefault();
      handleSuggestionClick(suggestions[activeIndex]);
    } else if (e.key === "Escape") {
      setShowSuggestions(false);
      setActiveIndex(-1);
    }
  };

  // Yash Dodiya setAIResponse(null);
  // --- Reusable Search Function ---
  const performSearch = useCallback(async (term: string) => {
    setAIResponse(null);
    setShowSuggestions(false);
    setSearchError("");
    setActiveIndex(-1);

    if (!term.trim()) {
      setSearchResults(null);
      return;
    }

    if (term.length > 40) {
      setSearchError("Search query cannot exceed 40 characters.");
      return;
    }

    const alphanumericRegex = /^[a-zA-Z0-9 ]*$/;
    if (!alphanumericRegex.test(term)) {
      setSearchError("Search contains invalid characters. Use only letters and numbers.");
      return;
    }

    setIsSearching(true);
    try {
      const baseUrl = process.env.NEXT_PUBLIC_API_URL || "http://localhost:4000";
      const response = await fetch(`${baseUrl}/api/search?query=${encodeURIComponent(term)}`);
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Search failed");

      setSearchResults(data.results);
      setCurrentPage(1);
    } catch (err: any) {
      console.error("Search Error:", err);
      setSearchError(err?.message || "An error occurred while searching.");
      setSearchResults([]);
    } finally {
      setIsSearching(false);
    }
  }, []);

  // Yash Dodiya
  // --- AI Search Function ---
  const performAISearch = useCallback(
    async (term: string) => {
      setSearchError("");
      setAIResponse(null);

      if (!term.trim()) {
        setSearchResults(null);
        return;
      }

      const result = await aiSearch(term);

      if (result) {
        setSearchResults(result.results);
        setAIResponse(result.aiResponse);
      } else if (aiSearchError) {
        setSearchError(aiSearchError);
        setSearchResults([]);
      }
    },
    [aiSearch, aiSearchError]
  );

  // Effect: Trigger search immediately if URL has a query
  useEffect(() => {
    if (urlQuery && !hasSearchedUrlQuery.current) {
      hasSearchedUrlQuery.current = true;
      setSearchQuery(urlQuery);
      if (isAIMode) {
        performAISearch(urlQuery);
      } else {
        performSearch(urlQuery);
      }
    }
  }, [urlQuery, isAIMode]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isAIMode) {
      performAISearch(searchQuery);
    } else {
      performSearch(searchQuery);
    }
  };

  const clearSearch = () => {
    setAIResponse(null);
    setSearchQuery("");
    setSearchResults(null);
    setSearchError("");
    setSuggestions([]);
    hasSearchedUrlQuery.current = false;
    router.replace("/events");
  };

  const toggleSearchMode = () => {
    setIsAIMode(!isAIMode);
    setSearchResults(null);
    setAIResponse(null);
    setSearchError("");
    hasSearchedUrlQuery.current = false;
  };

  // Determine which dataset to use
  const baseEvents = searchResults !== null ? searchResults : initialEvents;
  const isLoading = isInitialLoading || isSearching || isAISearching;

  const filterOptions = useMemo(() => {
    return {
      categories: Array.from(new Set(baseEvents.map((e) => e.category?.name).filter(Boolean))),
      venues: Array.from(new Set(baseEvents.map((e) => e.venue?.name).filter(Boolean))),
      organizers: Array.from(new Set(baseEvents.map((e) => e.organizer?.name).filter(Boolean))),
      languages: Array.from(
        new Set(baseEvents.flatMap((e) => e.languages?.map((l: any) => l.language_name) || []))
      ),
    };
  }, [baseEvents]);

  // FIX (Copilot): Wrapped in useMemo to prevent unnecessary re-filtering
  const filteredEvents = useMemo(() => {
    return baseEvents.filter((event) => {
      if (filters.category && event.category?.name !== filters.category) return false;
      if (filters.venue && event.venue?.name !== filters.venue) return false;
      if (filters.organizer && event.organizer?.name !== filters.organizer) return false;
      if (
        filters.language &&
        !event.languages?.some((l: any) => l.language_name === filters.language)
      )
        return false;

      if (filters.price) {
        const priceVal = parseFloat(event.price || "0");
        if (filters.price === "free" && priceVal > 0) return false;
        if (filters.price === "paid" && priceVal === 0) return false;
      }

      if (filters.dateFilter) {
        if (!isDateInRange(event.date, filters.dateFilter, filters.specificDate)) {
          return false;
        }
      }

      if (filters.registrationsOpen) {
        if (!event.registration_start_date || !event.registration_end_date) {
          return false;
        }

        // FIX (Copilot): Use Date-only comparison (midnight vs midnight)
        // This ensures that if today is the "End Date", it is still included.
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const nowDateOnly = today.getTime();

        const regStart = parseLocalDate(event.registration_start_date).getTime();
        const regEnd = parseLocalDate(event.registration_end_date).getTime();

        if (nowDateOnly < regStart || nowDateOnly > regEnd) {
          return false;
        }
      }

      return true;
    });
  }, [baseEvents, filters]);

  const sortedEvents = useMemo(() => {
    const now = new Date().getTime();
    return [...filteredEvents].sort((a, b) => {
      const timeA = new Date(`${a.date}T${a.start_time || "00:00:00"}`).getTime();
      const timeB = new Date(`${b.date}T${b.start_time || "00:00:00"}`).getTime();
      const isPastA = timeA < now;
      const isPastB = timeB < now;
      if (isPastA !== isPastB) return isPastA ? 1 : -1;
      return !isPastA ? timeA - timeB : timeB - timeA;
    });
  }, [filteredEvents]);

  // --- Pagination Logic ---
  const totalPages = Math.ceil(sortedEvents.length / ITEMS_PER_PAGE);
  const paginatedEvents = sortedEvents.slice(
    (currentPage - 1) * ITEMS_PER_PAGE,
    currentPage * ITEMS_PER_PAGE
  );

  // Reset pagination if filters reduce results below current page
  useEffect(() => {
    if (totalPages > 0 && currentPage > totalPages) {
      setCurrentPage(1);
    }
  }, [totalPages, currentPage]);

  const handlePageChange = (newPage: number) => {
    if (newPage >= 1 && newPage <= totalPages) {
      setCurrentPage(newPage);
      window.scrollTo({ top: 300, behavior: "smooth" });
    }
  };

  const handleFilterChange = (key: string, value: any) => {
    setFilters((prev) => ({ ...prev, [key]: value }));
    setCurrentPage(1);
  };

  const clearFilters = () => {
    setFilters({
      category: "",
      price: "",
      language: "",
      venue: "",
      organizer: "",
      dateFilter: "",
      specificDate: "",
      registrationsOpen: false,
    });
    setCurrentPage(1);
  };

  const hasActiveFilters = Object.values(filters).some((val) => val !== "" && val !== false);

  if (isInitialLoading && !searchResults)
    return <Spinner size="size-6" message="Loading events..." fullPage />;

  if (error)
    return (
      <NotFound
        title="Events Not Found"
        message="Error loading events."
        actionLabel="Home"
        actionHref="/"
      />
    );

  return (
    <div className="min-h-screen bg-linear-to-br from-slate-50 via-white to-green-50/30 px-4 py-12 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl">
        <div className="text-center">
          <h1 className="mb-4 bg-linear-to-r from-slate-900 via-green-900 to-slate-900 bg-clip-text text-4xl font-bold tracking-tight text-transparent sm:text-3xl">
            Events & Activities
          </h1>
          <p className="mx-auto mb-4 max-w-2xl text-lg leading-relaxed text-slate-600">
            Discover and participate in exciting events happening at Fulda.
          </p>
          {user?.role === "Organizer" && (
            <Link href="/create-event">
              <Button variant="default" className="mb-8">
                <Plus className="h-5 w-5" /> Host an Event
              </Button>
            </Link>
          )}

          {/* Yash Dodiya */}
          {/* --- AI MODE TOGGLE --- */}
          <div className="mx-auto mb-6 flex max-w-2xl items-center justify-center gap-3">
            <span className="flex items-center gap-2 text-sm font-medium text-slate-600">
              <Search className="h-4 w-4" />
              Search
            </span>

            <Switch
              onCheckedChange={toggleSearchMode}
              checked={isAIMode}
              className="data-[state=checked]:bg-green-600 data-[state=unchecked]:bg-slate-300"
            />

            <span
              className={`flex items-center gap-2 text-sm font-medium ${
                isAIMode ? "text-slate-900" : "text-slate-500"
              }`}
            >
              <Sparkles className="h-4 w-4" />
              AI
            </span>
          </div>
        </div>

        {/* --- SEARCH BAR SECTION --- */}
        <div className="relative mx-auto mb-8 max-w-2xl" ref={searchContainerRef}>
          <form onSubmit={handleSearchSubmit} className="relative flex items-center">
            {/* FIX (Copilot): Accessibility attributes for keyboard navigation */}
            <input
              type="text"
              placeholder={
                isAIMode
                  ? "Ask anything... (e.g., 'Find free music events next week')"
                  : isMobile
                    ? "Search events..."
                    : "Search events by title or description..."
              }
              role="combobox"
              aria-expanded={showSuggestions}
              aria-controls="search-suggestions-list"
              aria-activedescendant={activeIndex >= 0 ? `suggestion-${activeIndex}` : undefined}
              onKeyDown={handleKeyDown}
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                if (searchError) setSearchError("");
                if (e.target.value.length >= 2) setShowSuggestions(true);
              }}
              onFocus={() => {
                if (suggestions.length > 0) setShowSuggestions(true);
              }}
              className={`w-full rounded-full border bg-white py-3 pr-28 pl-12 text-slate-700 shadow-sm transition-all focus:ring-2 focus:outline-none ${
                searchError
                  ? "border-red-500 focus:border-red-500 focus:ring-red-500/20"
                  : isAIMode
                    ? "border-slate-300 focus:border-green-500 focus:ring-green-500/20"
                    : "border-slate-300 focus:border-green-500 focus:ring-green-500/20"
              } ${isAISearching ? "animate-pulse" : ""}`}
            />
            {isAIMode ? (
              <Sparkles className="absolute top-1/2 left-4 h-5 w-5 -translate-y-1/2 text-green-600" />
            ) : (
              <Search
                className={`absolute top-1/2 left-4 h-5 w-5 -translate-y-1/2 ${searchError ? "text-red-400" : "text-slate-400"}`}
              />
            )}

            {/* Search Action Buttons */}
            <div className="absolute right-2 flex items-center gap-1">
              {(searchQuery || searchResults) && (
                <button
                  type="button"
                  onClick={clearSearch}
                  className="rounded-full p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-600"
                  aria-label="Clear search"
                >
                  <X className="h-4 w-4" />
                </button>
              )}
              <Button
                type="submit"
                disabled={isSearching}
                className={`h-8 rounded-full px-4 text-xs ${
                  searchError ? "bg-red-600 hover:bg-red-700" : ""
                }`}
              >
                {isLoading ? (
                  <span className="animate-pulse">
                    {isAIMode ? "AI Thinking..." : "Searching..."}
                  </span>
                ) : (
                  "Search"
                )}
              </Button>
            </div>
          </form>

          {searchError && (
            <div className="animate-in fade-in slide-in-from-top-1 mt-2 flex items-center justify-center gap-2 text-sm font-medium text-red-600">
              <AlertCircle className="h-4 w-4" />
              <span>{searchError}</span>
            </div>
          )}

          {/* FIX (Copilot): Accessible Dropdown with Keyboard selection styles */}
          {showSuggestions && suggestions.length > 0 && (
            <div
              id="search-suggestions-list"
              role="listbox"
              className="absolute z-50 mt-2 w-full overflow-hidden rounded-xl border border-slate-200 bg-white shadow-xl ring-1 ring-slate-200"
            >
              <ul className="max-h-64 overflow-y-auto">
                {suggestions.map((item, index) => (
                  <li
                    key={`${item.type}-${item.id}-${index}`}
                    id={`suggestion-${index}`}
                    role="option"
                    aria-selected={activeIndex === index}
                    className="border-b border-slate-100 last:border-none"
                  >
                    <button
                      type="button"
                      onClick={() => handleSuggestionClick(item)}
                      className={`flex w-full cursor-pointer items-center justify-between px-4 py-3 text-left focus:outline-none ${
                        activeIndex === index ? "bg-slate-100" : "hover:bg-slate-50"
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className={`flex h-8 w-8 items-center justify-center rounded-full ${item.type === "Organizer" ? "bg-purple-100 text-purple-600" : item.type === "Category" ? "bg-blue-100 text-blue-600" : "bg-green-100 text-green-600"}`}
                        >
                          {item.type === "Organizer" ? (
                            <User className="h-4 w-4" />
                          ) : item.type === "Category" ? (
                            <Tag className="h-4 w-4" />
                          ) : (
                            <Calendar className="h-4 w-4" />
                          )}
                        </div>
                        <div className="flex flex-col">
                          <span className="text-sm font-medium text-slate-700">{item.text}</span>
                          <span className="text-[10px] font-semibold tracking-wider text-slate-400 uppercase">
                            {item.type}
                          </span>
                        </div>
                      </div>
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {searchResults !== null && !searchError && (
            <p className="mt-2 text-center text-sm text-slate-500">
              Showing results for "<span className="font-semibold">{searchQuery}</span>"
            </p>
          )}
        </div>

        {/* --- FILTER SECTION --- */}
        {!isAIMode && (
          <div className="mb-8 rounded-xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
            <div className="mb-4 flex flex-wrap items-center justify-between gap-4">
              <h2 className="flex items-center gap-2 text-sm font-semibold tracking-wider text-slate-500 uppercase">
                <Filter className="h-4 w-4" /> Filter Events
              </h2>

              <div className="flex items-center gap-3">
                <button
                  onClick={() => setShowAdvancedFilters(!showAdvancedFilters)}
                  className={`flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-medium transition-all ${
                    showAdvancedFilters
                      ? "bg-slate-100 text-slate-900"
                      : "text-slate-500 hover:bg-slate-50 hover:text-slate-700"
                  }`}
                >
                  <SlidersHorizontal className="h-3.5 w-3.5" />
                  {showAdvancedFilters ? "Hide Advanced" : "Advanced Filters"}
                </button>

                {hasActiveFilters && (
                  <button
                    onClick={clearFilters}
                    className="flex items-center gap-1 text-xs font-medium text-red-600 hover:text-red-700 hover:underline"
                  >
                    <X className="h-3 w-3" /> Clear Filters
                  </button>
                )}
              </div>
            </div>

            {/* BASIC FILTERS */}
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
              <select
                value={filters.category}
                onChange={(e) => handleFilterChange("category", e.target.value)}
                className="w-full rounded-lg border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-700 focus:border-green-500 focus:ring-green-500"
              >
                <option value="">All Categories</option>
                {filterOptions.categories.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>

              <select
                value={filters.language}
                onChange={(e) => handleFilterChange("language", e.target.value)}
                className="w-full rounded-lg border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-700 focus:border-green-500 focus:ring-green-500"
              >
                <option value="">All Languages</option>
                {filterOptions.languages.map((l) => (
                  <option key={l} value={l}>
                    {l}
                  </option>
                ))}
              </select>

              <select
                value={filters.price}
                onChange={(e) => handleFilterChange("price", e.target.value)}
                className="w-full rounded-lg border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-700 focus:border-green-500 focus:ring-green-500"
              >
                <option value="">Any Price</option>
                <option value="free">Free Only</option>
                <option value="paid">Paid Events</option>
              </select>
            </div>

            {/* ADVANCED FILTERS */}
            {showAdvancedFilters && (
              <div className="animate-in fade-in slide-in-from-top-2 mt-4 border-t border-slate-100 pt-4">
                <div className="grid grid-cols-1 items-center gap-4 sm:grid-cols-2 lg:grid-cols-4">
                  <div className="flex flex-col gap-1">
                    <select
                      value={filters.dateFilter}
                      onChange={(e) => handleFilterChange("dateFilter", e.target.value)}
                      className="w-full rounded-lg border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-700 focus:border-green-500 focus:ring-green-500"
                    >
                      <option value="">Any Date</option>
                      <option value="today">Today</option>
                      <option value="tomorrow">Tomorrow</option>
                      <option value="week">This Week</option>
                      <option value="weekend">This Weekend</option>
                      <option value="month">This Month</option>
                      <option value="specific">Specific Date</option>
                    </select>
                  </div>

                  <select
                    value={filters.venue}
                    onChange={(e) => handleFilterChange("venue", e.target.value)}
                    className="w-full rounded-lg border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-700 focus:border-green-500 focus:ring-green-500"
                  >
                    <option value="">All Venues</option>
                    {filterOptions.venues.map((v) => (
                      <option key={v} value={v}>
                        {v}
                      </option>
                    ))}
                  </select>

                  <select
                    value={filters.organizer}
                    onChange={(e) => handleFilterChange("organizer", e.target.value)}
                    className="w-full rounded-lg border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-700 focus:border-green-500 focus:ring-green-500"
                  >
                    <option value="">All Organizers</option>
                    {filterOptions.organizers.map((o) => (
                      <option key={o} value={o}>
                        {o}
                      </option>
                    ))}
                  </select>

                  {filters.dateFilter === "specific" && (
                    <div className="flex flex-col gap-1">
                      <label className="text-xs font-medium text-slate-500">Pick a Date</label>
                      <input
                        type="date"
                        value={filters.specificDate}
                        onChange={(e) => handleFilterChange("specificDate", e.target.value)}
                        className="w-full rounded-lg border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-700 focus:border-green-500 focus:ring-green-500"
                      />
                    </div>
                  )}

                  <div className="flex h-full items-center gap-2 pt-4 sm:col-span-2 sm:pt-0 lg:col-span-1">
                    <Checkbox
                      id="regOpen"
                      checked={filters.registrationsOpen}
                      onCheckedChange={(checked) =>
                        handleFilterChange("registrationsOpen", checked)
                      }
                    />
                    <label
                      htmlFor="regOpen"
                      className="cursor-pointer text-sm font-medium text-slate-700 select-none"
                    >
                      Registrations Open Only
                    </label>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* --- EVENTS GRID --- */}
        {isLoading && (searchResults !== null || isSearching || isAISearching) ? (
          <div className="py-20 text-center">
            <Spinner size="size-8" message={isAIMode ? "AI is thinking..." : "Searching..."} />
          </div>
        ) : paginatedEvents.length > 0 ? (
          <>
            <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
              {paginatedEvents.map((event) => (
                <EventCard
                  key={event.id}
                  id={event.id}
                  title={event.title}
                  date={event.date}
                  startTime={event.start_time.substring(0, 5)}
                  endTime={event.end_time.substring(0, 5)}
                  category={event.category.name}
                  price={event.price}
                  location={event.venue.name}
                  imageUrl={event.banner_image}
                  languages={event.languages?.map((l: any) => l.language_name) || []}
                  isFavorited={favouriteEventIds.has(event.id)}
                  onToggleFavourite={() => toggleFavourite(event.id, event.title)}
                  loggedIn={!!user}
                />
              ))}
            </div>

            {/* Pagination Controls */}
            {totalPages > 1 && (
              <div className="mt-12 flex items-center justify-center gap-4">
                <Button
                  variant="outline"
                  onClick={() => handlePageChange(currentPage - 1)}
                  disabled={currentPage === 1}
                  className="flex items-center gap-1 pl-2"
                >
                  <ChevronLeft className="h-4 w-4" /> Previous
                </Button>

                <span className="text-sm font-medium text-slate-600">
                  Page {currentPage} of {totalPages}
                </span>

                <Button
                  variant="outline"
                  onClick={() => handlePageChange(currentPage + 1)}
                  disabled={currentPage === totalPages}
                  className="flex items-center gap-1 pr-2"
                >
                  Next <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            )}
          </>
        ) : (
          <div className="rounded-2xl border-2 border-dashed border-slate-300 bg-white/50 py-20 text-center backdrop-blur-sm">
            <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-slate-100">
              {isAIMode ? (
                <Sparkles className="h-8 w-8 text-purple-400" />
              ) : (
                <Search className="h-8 w-8 text-slate-400" />
              )}
            </div>
            <h3 className="mb-2 text-xl font-semibold text-slate-900">No events found</h3>
            <p className="mb-6 text-slate-600">
              {searchResults !== null
                ? isAIMode
                  ? "AI couldn't find any events matching your query."
                  : "No events match your search query and selected filters."
                : "No events match your current filters."}
            </p>
            {(hasActiveFilters || searchResults !== null) && (
              <div className="flex justify-center gap-2">
                {hasActiveFilters && (
                  <Button variant="outline" onClick={clearFilters}>
                    Clear Filters
                  </Button>
                )}
                {searchResults !== null && (
                  <Button variant="outline" onClick={clearSearch}>
                    Clear Search
                  </Button>
                )}
              </div>
            )}
          </div>
        )}
      </div>

      {showScrollTop && (
        <button
          onClick={scrollToTop}
          className="fixed right-6 bottom-6 flex h-12 w-12 items-center justify-center rounded-full bg-green-600 text-white shadow-lg transition-all hover:scale-110 hover:bg-green-700 active:scale-95 sm:right-10 sm:bottom-10"
          aria-label="Scroll to top"
        >
          <ArrowUp className="h-6 w-6" />
        </button>
      )}
    </div>
  );
}
