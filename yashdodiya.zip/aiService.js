const { OpenRouter, tool } = require("@openrouter/sdk");
const { z } = require("zod");
const { Event, Category, Venue } = require("../models");
const { Op } = require("sequelize");

const openrouter = new OpenRouter({
  apiKey: process.env.OPENROUTER_API_KEY || "",
});

// Helper function to get date range
function getDateRange(dateRangeType) {
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const tomorrow = new Date(today);
  tomorrow.setDate(tomorrow.getDate() + 1);

  const endOfWeek = new Date(today);
  endOfWeek.setDate(today.getDate() + (7 - today.getDay()));

  const startOfNextWeek = new Date(endOfWeek);
  startOfNextWeek.setDate(endOfWeek.getDate() + 1);

  const endOfNextWeek = new Date(startOfNextWeek);
  endOfNextWeek.setDate(startOfNextWeek.getDate() + 6);

  const endOfMonth = new Date(today.getFullYear(), today.getMonth() + 1, 0);

  const startOfNextMonth = new Date(today.getFullYear(), today.getMonth() + 1, 1);
  const endOfNextMonth = new Date(today.getFullYear(), today.getMonth() + 2, 0);

  switch (dateRangeType) {
    case "today":
      return { start: today, end: today };
    case "tomorrow":
      return { start: tomorrow, end: tomorrow };
    case "this_week":
      return { start: today, end: endOfWeek };
    case "next_week":
      return { start: startOfNextWeek, end: endOfNextWeek };
    case "this_month":
      return { start: today, end: endOfMonth };
    case "next_month":
      return { start: startOfNextMonth, end: endOfNextMonth };
    case "future":
      return { start: today, end: null };
    default:
      return { start: today, end: null };
  }
}

// Tool 1: Search Events
const searchEventsTool = tool({
  name: "search_events",
  description:
    "Search for events using various filters like keywords, category, price range, date range, and location. Returns a list of matching approved events. Use this when users ask about finding, searching, or listing events.",
  inputSchema: z.object({
    query: z.string().optional().describe("Search keywords to match in event title or description"),
    category: z
      .string()
      .optional()
      .describe("Category name to filter by (e.g., Sports, Music, Workshop, Cultural)"),
    subcategory: z.string().optional().describe("Subcategory name to filter by"),
    minPrice: z.number().optional().describe("Minimum price filter in euros"),
    maxPrice: z
      .number()
      .optional()
      .describe("Maximum price filter in euros. Use 0 for free events"),
    dateRange: z
      .enum(["today", "tomorrow", "this_week", "next_week", "this_month", "next_month", "future"])
      .optional()
      .describe("Predefined date range filter"),
    startDate: z.string().optional().describe("Custom start date in YYYY-MM-DD format"),
    endDate: z.string().optional().describe("Custom end date in YYYY-MM-DD format"),
    venue: z.string().optional().describe("Venue or location name"),
    limit: z
      .number()
      .default(10)
      .describe("Maximum number of results to return (default 10, max 50)"),
  }),
  outputSchema: z.object({
    success: z.boolean(),
    count: z.number(),
    events: z.array(
      z.object({
        id: z.number(),
        title: z.string(),
        description: z.string().nullable(),
        price: z.string(),
        date: z.string(),
        start_time: z.string().nullable(),
        end_time: z.string().nullable(),
        banner_image: z.string().nullable(),
        category: z
          .object({
            id: z.number(),
            name: z.string(),
          })
          .nullable(),
        venue: z
          .object({
            id: z.number(),
            name: z.string(),
            building_name: z.string().nullable(),
            floor_name: z.string().nullable(),
            latitude: z.string().nullable(),
            longitude: z.string().nullable(),
          })
          .nullable(),
        organizer: z
          .object({
            id: z.number(),
            name: z.string(),
            email: z.string(),
          })
          .nullable(),
        languages: z.array(
          z.object({
            language_id: z.number(),
            language_name: z.string(),
            EventLanguage: z.object({
              id: z.number(),
              eventId: z.number(),
              languageId: z.number(),
            }),
          })
        ),
      })
    ),
  }),
  execute: async (params) => {
    try {
      const {
        query,
        category,
        subcategory,
        minPrice,
        maxPrice,
        dateRange,
        startDate,
        endDate,
        venue,
        limit = 10,
      } = params;

      const where = { status: "approved" };

      // Price filter
      if (minPrice !== undefined || maxPrice !== undefined) {
        where.price = {};
        if (minPrice !== undefined) where.price[Op.gte] = minPrice;
        if (maxPrice !== undefined) where.price[Op.lte] = maxPrice;
      }

      // Date filter
      if (dateRange) {
        const { start, end } = getDateRange(dateRange);
        where.date = end ? { [Op.between]: [start, end] } : { [Op.gte]: start };
      } else if (startDate || endDate) {
        where.date = {};
        if (startDate) where.date[Op.gte] = startDate;
        if (endDate) where.date[Op.lte] = endDate;
      }

      // Keyword search
      if (query) {
        const searchTerms = query
          .toLowerCase()
          .split(/\s+/)
          .filter((t) => t.length > 2);
        const orConditions = [];

        // Search for full query
        orConditions.push(
          { title: { [Op.like]: `%${query}%` } },
          { description: { [Op.like]: `%${query}%` } }
        );

        // Also search for individual terms (broader search)
        searchTerms.forEach((term) => {
          orConditions.push(
            { title: { [Op.like]: `%${term}%` } },
            { description: { [Op.like]: `%${term}%` } }
          );
        });

        where[Op.or] = orConditions;
      }

      // Category filter
      const include = [
        { association: "organizer", attributes: ["id", "name", "email"] },
        { association: "venue" },
        { association: "category" },
        { association: "subcategories" },
        { association: "languages" },
      ];

      if (category) {
        where["$category.name$"] = { [Op.like]: `%${category}%` };
      }

      if (subcategory) {
        where["$subcategories.name$"] = { [Op.like]: `%${subcategory}%` };
      }

      if (venue) {
        where["$venue.name$"] = { [Op.like]: `%${venue}%` };
      }

      const events = await Event.findAll({
        where,
        include,
        limit: Math.min(limit, 50),
        order: [["date", "ASC"]],
        subQuery: false,
      });

      return {
        success: true,
        count: events.length,
        events: events.map((e) => ({
          id: e.id,
          title: e.title,
          description: e.description?.substring(0, 200) || null,
          price: e.price?.toString() || "0",
          date: e.date,
          start_time: e.start_time,
          end_time: e.end_time,
          banner_image: e.banner_image,
          category: e.category || null,
          venue: e.venue || null,
          organizer: e.organizer || null,
          languages: e.languages || [],
        })),
      };
    } catch (error) {
      console.error("Error in searchEventsTool:", error);
      return { success: false, count: 0, events: [] };
    }
  },
});

// Main function to handle AI search
async function processNaturalLanguageSearch(userQuery) {
  try {
    let capturedToolCall = null;
    let capturedToolResult = null;

    const result = openrouter.callModel({
      model: "nvidia/nemotron-3-nano-30b-a3b:free",
      // Lines 215-220 - Replace the prompt with:
      input: `You are an event search assistant for Fulda Events Hub. 

INSTRUCTIONS:
1. Use search_events with relevant keywords from the user's query
2. Analyze FULL event descriptions for semantic meaning and context
3. Rank results by true relevance to user intent (not just keyword matching)
4. Present the most relevant events first

RELEVANCE CRITERIA:
- Semantic meaning: "relaxing" → spa, meditation, calm, peaceful, chill
- Location/venue matching: "by lake" → lakeside, waterfront, outdoor
- Activity type: "music" → concert, performance, band, acoustic
- Mood/atmosphere from description
- Combined context (e.g., "relaxing music by lake" needs ALL aspects)

IMPORTANT: 
- Read the FULL description of each event
- Match user's intent, not just literal words
- Prioritize events that match multiple aspects of the query

Current date: ${new Date().toISOString().split("T")[0]}

User query: ${userQuery}`,
      tools: [searchEventsTool],
    });

    // Capture tool execution in real-time
    for await (const event of result.getFullResponsesStream()) {
      if (event.type === "tool.result") {
        console.log("Tool result received.", event);
        console.log("Tool executed:", event.toolCallId);
        capturedToolCall = event.toolCallId;
        capturedToolResult = event.result;
        // console.log("Tool result:", event.result);
      }
    }

    // Get final text response
    const responseText = await result.getText();

    return {
      message: responseText,
      functionCalled: capturedToolCall,
      results: capturedToolResult,
    };
  } catch (error) {
    console.error("Error in AI search:", error);
    throw error;
  }
}

module.exports = { processNaturalLanguageSearch };
